NFS GINTool
-----------------------------------------------------------
This tools allows for GIN files to be encoded in a more convenient and fast way. No HEX editing needed anymore.


Encoding process
-----------------------------------------------------------
-- Using the REV tool, map the RPM values and note down minimum and maximun IDX and RPM values, export grains
-- Using the GINTool, navigate to the wav file that you're about to convert to gin, input your min and max IDX and RPM values
-- Optionally you can select custom grain and export paths. By default, grain path is a directory in the same folder
        as WAV that's named as it, but without its extension, and the GIN export path in the same location as WAV
-- Press "Encode GIN" and wait for the process to complete, and you're done!


Installation
-----------------------------------------------------------
-- GINTool 1.3 requires JRE or JDK 11 or higher, any version lower than 1.3 requires JRE or JDK 8 with JavaFX included.
        You can download and install it here:
            JDK FX 8: https://www.azul.com/downloads/?version=java-8-lts&os=windows&architecture=x86-64-bit&package=jdk-fx
            JRE 11: https://www.azul.com/downloads/?version=java-11-lts&os=windows&architecture=x86-64-bit&package=jre#zulu
-- GINTool also requires FFMPEG to be in the same location as GINTool.
            Download it here: https://www.gyan.dev/ffmpeg/builds/
            Essential build is enough. Unzip the ffmpeg.exe into GINTool's location
-- (NO LONGER REQUIRED VERSION IN 1.3) gin_encode and gin2 require Visual C++ Redistributable for Visual Studio 2015
            and Universal C Runtime (Universal CRT) (Debug version) to be installed. They are included with Visual Studio.
            After that, you can copy vcruntime140d.dll and ucrtbased.dll into tool's folder.


FAQ
-----------------------------------------------------------
-- Q: How do I launch GINTool?
-- A: Via launchGIN.bat. If you launch it directly via .jar file, your mileage may vary
-- Q: Is REV stage necessary?
-- A: Yes. This tool is just to simplify the process of already existing encoding procedure. It's described here


Changelog
-----------------------------------------------------------
-- 1.0: Initial release
-- 1.1: UI Logic fixes
-- 1.2: Added ability to encode deceleration GIN's, major performance improvements
-- 1.2.1: Added failsaves for gin_encode and gin2
-- 1.3: Major code refactoring. Fields now support decimals. Tool now uses/requires JDK/JRE 11 to be installed, potential accuracy improvements
        by porting algorithm of gin2.exe to java code, which also removes the requirement of gin2.exe,
        vcruntime140d.dll and ucrtbased.dll altogether
-- 1.3.1: Small UI changes, improved .ini logic, algorithmic number of threads calculation
-- 1.3.2: More UI changes, new fields for NFS Carbon and .ini stores more data
-- 1.3.3: UI changes, multilanguage support, rewritten "Launch TMXTool" logic. Be sure to have tmxtool.jar and launchTMX.bat at the same location as GINTool


Known issues
-----------------------------------------------------------
-- (NO LONGER AN ISSUE VERSION IN 1.3) gin_encode and gin2.exe require Visual C++ Redistributable for Visual Studio 2015
            and Universal C Runtime (Universal CRT) to be installed.
            If they are not installed, you might get issues with encoding process.


Credits
-----------------------------------------------------------
-- Azul for their JDK project
-- id-daemon for original GIN encoders
-- gyan.dev for providing FFMPEG build
-- V12Style for the tutorial that the tool was based on

Source code available here: https://github.com/TheUnpunished/gintool
If you want to contribute to the project (add a translation, etc.),
                don't hesitate to make pull requests.
                Example messages file can be seen here: https://github.com/TheUnpunished/gintool/blob/main/src/main/resources/i18n/messages_en.properties
