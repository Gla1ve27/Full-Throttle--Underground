using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

namespace Underground.Audio.V2
{
    /// <summary>
    /// Manages engine loop crossfading: idle, on-throttle bands, off-throttle bands,
    /// and top/redline loop. Reads exclusively from <see cref="EngineAudioStateFeed"/>.
    ///
    /// Supports both inline-authored loops and NFSU2CarAudioBank-sourced loops.
    /// </summary>
    public sealed class EngineLayerPlayer : MonoBehaviour
    {
        private enum LoopBank { Idle, OnThrottle, OffThrottle, Top }

        [Serializable]
        public sealed class EngineLoopDef
        {
            public string label = "Loop";
            public AudioClip clip;
            public float referenceRPM = 3000f;
            public float minRPM = 1800f;
            public float maxRPM = 4200f;
            [Range(0f, 1.5f)] public float baseVolume = 0.65f;
            [Range(0.25f, 2.5f)] public float basePitch = 1f;
            [Range(0f, 1f)] public float throttleAggression = 0.5f;
        }

        private sealed class Runtime
        {
            public EngineLoopDef Settings;
            public LoopBank Bank;
            public AudioSource Source;
            public float TargetVolume;
            public float TargetPitch = 1f;
        }

        [Header("Main Loops")]
        [SerializeField] private EngineLoopDef idleLoop;
        [SerializeField] private EngineLoopDef[] onThrottleLoops;
        [SerializeField] private EngineLoopDef topLoop;
        [SerializeField] private EngineLoopDef[] offThrottleLoops;

        [Header("Blend")]
        [SerializeField, Range(1, 4)] private int dominantLoopLimit = 3;
        [SerializeField, Range(0.1f, 1.2f)] private float busVolumeCeiling = 0.9f;
        [SerializeField, Range(0f, 1f)] private float minimumBedVolume = 0.32f;
        [SerializeField, Range(0f, 0.45f)] private float rpmBandOverlap = 0.32f;
        [SerializeField, Range(0f, 1f)] private float offThrottleFloor = 0.34f;
        [SerializeField, Range(0f, 1f)] private float idleThrottleSuppression = 0.36f;
        [SerializeField, Range(0f, 1f)] private float throttleFullTone = 0.78f;
        [SerializeField, Range(0f, 1f)] private float topLoopThrottleThreshold = 0.7f;
        [SerializeField, Range(0f, 1f)] private float highRpmAggressionBoost = 0.18f;
        [SerializeField] private Vector2 pitchClamp = new Vector2(0.72f, 1.28f);
        [SerializeField, Range(0.02f, 0.4f)] private float pitchClampFadeRange = 0.16f;

        [Header("Smoothing")]
        [SerializeField] private float volumeResponse = 16f;
        [SerializeField] private float pitchResponse = 9f;

        [Header("Spatial")]
        [SerializeField, Range(0f, 1f)] private float masterVolume = 0.9f;
        [SerializeField, Range(0f, 1f)] private float spatialBlend = 0.78f;
        [SerializeField] private float minDistance = 3f;
        [SerializeField] private float maxDistance = 55f;
        [SerializeField] private AudioMixerGroup outputGroup;

        [Header("Shift")]
        [SerializeField, Range(0f, 1f)] private float shiftVolumeDuck = 0.16f;
        [SerializeField] private float shiftDuckDuration = 0.11f;
        [SerializeField, Range(0f, 0.1f)] private float shiftPitchDip = 0.012f;

        [Header("Limiter")]
        [SerializeField] private bool enableSoftLimiter = true;
        [SerializeField, Range(0f, 1f)] private float limiterEnterRpm01 = 0.955f;
        [SerializeField, Range(0f, 0.25f)] private float limiterVolumePulse = 0.08f;
        [SerializeField, Range(4f, 30f)] private float limiterPulseHz = 13f;

        private readonly List<Runtime> runtimes = new List<Runtime>(10);
        private Transform sourceRoot;
        private float shiftDuckTimer;
        private bool hasOffBank;
        private bool initialized;

        public void Initialize(Transform root)
        {
            sourceRoot = root;
            RebuildSources();
            initialized = true;
        }

        /// <summary>
        /// Populate from an NFSU2CarAudioBank tier. Called by VehicleAudioControllerV2
        /// during bank application.
        /// </summary>
        public void ApplyFromBank(NFSU2CarAudioBank.TierAudioPackage tier, bool isExterior)
        {
            if (tier == null) return;

            // Idle
            if (idleLoop == null) idleLoop = new EngineLoopDef();
            idleLoop.clip = isExterior ? tier.idle.exteriorClip : tier.idle.interiorClip;
            idleLoop.baseVolume = isExterior ? tier.idle.exteriorVolume : tier.idle.interiorVolume;
            idleLoop.referenceRPM = 900f;
            idleLoop.minRPM = 650f;
            idleLoop.maxRPM = 1500f;

            // On-throttle from accelLow/Mid/High
            onThrottleLoops = new[]
            {
                MakeLoopDef("Low On", tier.accelLow, isExterior, 1800f, 1050f, 3000f),
                MakeLoopDef("Mid On", tier.accelMid, isExterior, 4400f, 2500f, 5200f),
                MakeLoopDef("High On", tier.accelHigh, isExterior, 5900f, 4700f, 7200f)
            };

            // Top/limiter
            if (topLoop == null) topLoop = new EngineLoopDef();
            topLoop.clip = isExterior ? tier.limiter.exteriorClip : tier.limiter.interiorClip;
            topLoop.baseVolume = isExterior ? tier.limiter.exteriorVolume : tier.limiter.interiorVolume;
            topLoop.referenceRPM = 7300f;
            topLoop.minRPM = 6800f;
            topLoop.maxRPM = 8200f;

            // Off-throttle from decelLow/Mid/High
            offThrottleLoops = new[]
            {
                MakeLoopDef("Low Off", tier.decelLow, isExterior, 1800f, 1100f, 3000f),
                MakeLoopDef("Mid Off", tier.decelMid, isExterior, 4400f, 2500f, 5200f),
                MakeLoopDef("High Off", tier.decelHigh, isExterior, 5900f, 4700f, 7200f)
            };

            if (initialized) RebuildSources();
        }

        public void UpdateLayers(EngineAudioStateFeed feed, float dt)
        {
            if (!initialized || feed == null) return;

            shiftDuckTimer = Mathf.Max(0f, shiftDuckTimer - dt);
            if (feed.ShiftJustStarted) shiftDuckTimer = shiftDuckDuration;

            float rpm = feed.SmoothedRPM;
            float rpm01 = feed.NormalizedRPM;
            float throttle = feed.SmoothedThrottle;
            float onBlend = feed.OnThrottleBlend;
            float throttleTone = Mathf.InverseLerp(0.1f, Mathf.Max(0.11f, throttleFullTone), throttle);

            float onLoad = hasOffBank ? Mathf.Lerp(0.08f, 1f, onBlend) : Mathf.Lerp(offThrottleFloor, 1f, throttleTone);
            float offLoad = hasOffBank ? Mathf.Lerp(1f, 0.08f, onBlend) : 0f;
            float highRpmBoost = 1f + highRpmAggressionBoost * Mathf.InverseLerp(0.58f, 0.96f, rpm01) * throttleTone;
            float shiftGain = shiftDuckTimer > 0f ? 1f - shiftVolumeDuck : 1f;
            float limiterGain = GetLimiterGain(rpm01);

            for (int i = 0; i < runtimes.Count; i++)
            {
                var r = runtimes[i];
                var s = r.Settings;
                float bandWeight = GetBandWeight(s, rpm);
                float pitchFade = GetPitchClampSoftGain(s, rpm);
                float bankLoad = ResolveBankLoad(r.Bank, onLoad, offLoad, throttleTone);
                float idleGain = r.Bank == LoopBank.Idle
                    ? Mathf.Lerp(1f, 1f - idleThrottleSuppression, throttleTone)
                    : 1f;

                float rawPitch = s.referenceRPM > 0f ? rpm / s.referenceRPM * s.basePitch : s.basePitch;
                float shiftPitch = feed.IsShifting ? -shiftPitchDip : 0f;
                r.TargetPitch = Mathf.Clamp(rawPitch + shiftPitch, pitchClamp.x, pitchClamp.y);
                r.TargetVolume = bandWeight * pitchFade * bankLoad * s.baseVolume * idleGain * highRpmBoost
                    * shiftGain * limiterGain * masterVolume;
            }

            // Dominance pass
            ApplyDominancePass();

            // Apply smoothed
            for (int i = 0; i < runtimes.Count; i++)
            {
                var r = runtimes[i];
                if (r.Source == null) continue;
                r.Source.volume = ExpSmooth(r.Source.volume, r.TargetVolume, volumeResponse, dt);
                r.Source.pitch = ExpSmooth(r.Source.pitch, r.TargetPitch, pitchResponse, dt);
                if (!r.Source.isPlaying && r.Source.clip != null) r.Source.Play();
            }
        }

        // ─────────────────────────────────────────────────────────────────────
        //  Internals
        // ─────────────────────────────────────────────────────────────────────

        private void RebuildSources()
        {
            runtimes.Clear();
            if (sourceRoot != null)
            {
                for (int i = sourceRoot.childCount - 1; i >= 0; i--)
                {
                    var child = sourceRoot.GetChild(i);
                    if (child.name.StartsWith("EL_")) Destroy(child.gameObject);
                }
            }

            hasOffBank = offThrottleLoops != null && offThrottleLoops.Length > 0;
            AddRuntime(idleLoop, LoopBank.Idle, "EL_Idle");
            AddRuntimes(onThrottleLoops, LoopBank.OnThrottle, "EL_On");
            AddRuntime(topLoop, LoopBank.Top, "EL_Top");
            AddRuntimes(offThrottleLoops, LoopBank.OffThrottle, "EL_Off");
        }

        private void AddRuntimes(EngineLoopDef[] loops, LoopBank bank, string prefix)
        {
            if (loops == null) return;
            for (int i = 0; i < loops.Length; i++) AddRuntime(loops[i], bank, $"{prefix}_{i:00}");
        }

        private void AddRuntime(EngineLoopDef loop, LoopBank bank, string name)
        {
            if (loop == null || sourceRoot == null) return;
            var go = new GameObject(name);
            go.transform.SetParent(sourceRoot, false);
            var src = go.AddComponent<AudioSource>();
            src.playOnAwake = false;
            src.loop = true;
            src.volume = 0f;
            src.pitch = 1f;
            src.priority = 96;
            src.dopplerLevel = 0f;
            src.spatialBlend = spatialBlend;
            src.rolloffMode = AudioRolloffMode.Linear;
            src.minDistance = minDistance;
            src.maxDistance = maxDistance;
            src.outputAudioMixerGroup = outputGroup;
            if (loop.clip != null) { src.clip = loop.clip; src.Play(); }
            runtimes.Add(new Runtime { Settings = loop, Bank = bank, Source = src });
        }

        private float GetBandWeight(EngineLoopDef s, float rpm)
        {
            float range = Mathf.Max(0.01f, s.maxRPM - s.minRPM);
            float overlap = range * rpmBandOverlap;
            float effectiveMin = s.minRPM - overlap;
            float effectiveMax = s.maxRPM + overlap;
            if (rpm < effectiveMin || rpm > effectiveMax) return 0f;
            float fadeIn = Mathf.InverseLerp(effectiveMin, s.minRPM, rpm);
            float fadeOut = Mathf.InverseLerp(effectiveMax, s.maxRPM, rpm);
            return Mathf.Min(fadeIn, fadeOut);
        }

        private float GetPitchClampSoftGain(EngineLoopDef s, float rpm)
        {
            if (s.referenceRPM <= 0f) return 1f;
            float rawPitch = rpm / s.referenceRPM * s.basePitch;
            float distLow = rawPitch - pitchClamp.x;
            float distHigh = pitchClamp.y - rawPitch;
            float dist = Mathf.Min(distLow, distHigh);
            if (dist >= pitchClampFadeRange) return 1f;
            return Mathf.Clamp01(dist / Mathf.Max(0.001f, pitchClampFadeRange));
        }

        private float ResolveBankLoad(LoopBank bank, float onLoad, float offLoad, float throttleTone)
        {
            switch (bank)
            {
                case LoopBank.Idle: return 1f;
                case LoopBank.OnThrottle: return onLoad;
                case LoopBank.OffThrottle: return offLoad;
                case LoopBank.Top: return throttleTone >= topLoopThrottleThreshold ? onLoad : onLoad * 0.3f;
                default: return 1f;
            }
        }

        private float GetLimiterGain(float rpm01)
        {
            if (!enableSoftLimiter || rpm01 < limiterEnterRpm01) return 1f;
            float pulse = Mathf.Sin(Time.time * limiterPulseHz * Mathf.PI * 2f) * 0.5f + 0.5f;
            return 1f - pulse * limiterVolumePulse;
        }

        private void ApplyDominancePass()
        {
            if (runtimes.Count <= dominantLoopLimit) return;

            // Find the top N volumes
            float threshold = 0f;
            for (int pass = 0; pass < dominantLoopLimit; pass++)
            {
                float highest = 0f;
                for (int i = 0; i < runtimes.Count; i++)
                {
                    float v = runtimes[i].TargetVolume;
                    if (v > highest && v > threshold) highest = v;
                }
                threshold = highest;
            }

            // Suppress everything below the threshold
            for (int i = 0; i < runtimes.Count; i++)
            {
                if (runtimes[i].TargetVolume < threshold * 0.5f)
                {
                    runtimes[i].TargetVolume *= 0.25f;
                }
            }

            // Bus ceiling
            float total = 0f;
            for (int i = 0; i < runtimes.Count; i++) total += runtimes[i].TargetVolume;
            if (total > busVolumeCeiling)
            {
                float scale = busVolumeCeiling / total;
                for (int i = 0; i < runtimes.Count; i++) runtimes[i].TargetVolume *= scale;
            }

            // Bed floor
            for (int i = 0; i < runtimes.Count; i++)
            {
                if (runtimes[i].TargetVolume > 0.01f)
                    runtimes[i].TargetVolume = Mathf.Max(runtimes[i].TargetVolume, minimumBedVolume * masterVolume);
            }
        }

        private static EngineLoopDef MakeLoopDef(string label, NFSU2CarAudioBank.AudioLoopLayer layer, bool exterior,
            float refRpm, float minRpm, float maxRpm)
        {
            return new EngineLoopDef
            {
                label = label,
                clip = exterior ? layer?.exteriorClip : layer?.interiorClip,
                baseVolume = exterior ? (layer?.exteriorVolume ?? 0.7f) : (layer?.interiorVolume ?? 0.55f),
                referenceRPM = refRpm,
                minRPM = minRpm,
                maxRPM = maxRpm,
                basePitch = 1f,
                throttleAggression = 0.5f
            };
        }

        private static float ExpSmooth(float a, float b, float r, float dt)
        {
            return Mathf.Lerp(a, b, 1f - Mathf.Exp(-r * dt));
        }
    }
}
