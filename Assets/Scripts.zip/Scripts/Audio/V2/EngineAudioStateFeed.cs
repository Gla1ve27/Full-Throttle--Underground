using UnityEngine;
using Underground.Vehicle.V2;

namespace Underground.Audio.V2
{
    /// <summary>
    /// Converts raw <see cref="VehicleState"/> into smooth, audio-optimized values.
    /// This is the ONLY entry point for the V2 audio system to read vehicle data.
    /// All smoothing and dead-banding happens here so individual players don't each
    /// apply their own inconsistent smoothing.
    /// </summary>
    public sealed class EngineAudioStateFeed : MonoBehaviour
    {
        [Header("Smoothing")]
        [SerializeField] private float rpmRiseResponse = 14f;
        [SerializeField] private float rpmFallResponse = 10f;
        [SerializeField] private float throttleResponse = 18f;
        [SerializeField] private float speedResponse = 10f;
        [SerializeField] private float slipAttackResponse = 8f;
        [SerializeField] private float slipReleaseResponse = 20f;

        [Header("Deadband")]
        [SerializeField] private float rpmDeadband = 18f;

        [Header("RPM Source")]
        [SerializeField] private float fallbackIdleRPM = 900f;
        [SerializeField] private float fallbackMaxRPM = 7800f;

        // ── Smoothed output values (read by audio players) ──
        public float SmoothedRPM { get; private set; }
        public float NormalizedRPM { get; private set; }
        public float SmoothedThrottle { get; private set; }
        public float SmoothedSpeedKph { get; private set; }
        public float SmoothedSlip { get; private set; }
        public float OnThrottleBlend { get; private set; }
        public float TurboSpool { get; private set; }
        public float LimiterAmount { get; private set; }
        public int Gear { get; private set; } = 1;
        public int PreviousGear { get; private set; } = 1;
        public bool IsGrounded { get; private set; }
        public bool IsReversing { get; private set; }
        public bool IsShifting { get; private set; }
        public float ShiftProgress { get; private set; }
        public ShiftDirection LastShiftDirection { get; private set; }
        public DriftPhase CurrentDriftPhase { get; private set; }
        public float EngineLoad { get; private set; }
        public float ClutchEngagement { get; private set; }

        // ── Shift detection ──
        public bool ShiftJustStarted { get; private set; }
        public bool ShiftJustEnded { get; private set; }

        private float onThrottleTarget;
        private bool wasShifting;
        private float idleRPM;
        private float maxRPM;

        [Header("Throttle Thresholds")]
        [SerializeField] private float throttleOnThreshold = 0.18f;
        [SerializeField] private float throttleOffThreshold = 0.10f;
        [SerializeField] private float onOffBlendResponse = 11f;

        private VehicleState vehicleState;

        public void Bind(VehicleState state, float idle = 0f, float max = 0f)
        {
            vehicleState = state;
            idleRPM = idle > 0f ? idle : fallbackIdleRPM;
            maxRPM = max > 0f ? max : fallbackMaxRPM;
            SmoothedRPM = idleRPM;
            NormalizedRPM = 0f;
        }

        public void UpdateFeed(float dt)
        {
            if (vehicleState == null || dt <= 0f)
            {
                return;
            }

            // ── RPM ──
            float rawRPM = Mathf.Clamp(vehicleState.EngineRPM, idleRPM, maxRPM);
            if (Mathf.Abs(rawRPM - SmoothedRPM) <= rpmDeadband)
            {
                rawRPM = SmoothedRPM;
            }

            float rpmRate = rawRPM >= SmoothedRPM ? rpmRiseResponse : rpmFallResponse;
            SmoothedRPM = ExpSmooth(SmoothedRPM, rawRPM, rpmRate, dt);
            NormalizedRPM = maxRPM > idleRPM ? Mathf.InverseLerp(idleRPM, maxRPM, SmoothedRPM) : 0f;

            // ── Throttle ──
            SmoothedThrottle = ExpSmooth(SmoothedThrottle, vehicleState.Throttle, throttleResponse, dt);

            // ── On/Off throttle blend ──
            if (SmoothedThrottle > throttleOnThreshold) onThrottleTarget = 1f;
            else if (SmoothedThrottle < throttleOffThreshold) onThrottleTarget = 0f;
            OnThrottleBlend = ExpSmooth(OnThrottleBlend, onThrottleTarget, onOffBlendResponse, dt);

            // ── Speed ──
            SmoothedSpeedKph = ExpSmooth(SmoothedSpeedKph, Mathf.Abs(vehicleState.ForwardSpeedKph), speedResponse, dt);

            // ── Slip ──
            float rawSlip = Mathf.Max(vehicleState.FrontSlip, vehicleState.RearSlip);
            float slipRate = rawSlip >= SmoothedSlip ? slipAttackResponse : slipReleaseResponse;
            SmoothedSlip = ExpSmooth(SmoothedSlip, rawSlip, slipRate, dt);

            // ── Direct reads ──
            Gear = vehicleState.Gear;
            PreviousGear = vehicleState.PreviousGear;
            IsGrounded = vehicleState.IsGrounded;
            IsReversing = vehicleState.IsReversing;
            TurboSpool = vehicleState.TurboSpoolAmount;
            LimiterAmount = vehicleState.LimiterAmount;
            EngineLoad = vehicleState.EngineLoad;
            ClutchEngagement = vehicleState.ClutchEngagement;
            CurrentDriftPhase = vehicleState.CurrentDriftPhase;

            // ── Shift edge detection ──
            IsShifting = vehicleState.IsShifting;
            ShiftProgress = vehicleState.ShiftProgress;
            LastShiftDirection = vehicleState.LastShiftDirection;
            ShiftJustStarted = IsShifting && !wasShifting;
            ShiftJustEnded = !IsShifting && wasShifting;
            wasShifting = IsShifting;
        }

        private static float ExpSmooth(float current, float target, float response, float dt)
        {
            return Mathf.Lerp(current, target, 1f - Mathf.Exp(-response * dt));
        }
    }
}
