using UnityEngine;
using Underground.Audio;
using Underground.Core.Architecture;
using Underground.Save;

namespace Underground.Vehicle.V2
{
    /// <summary>
    /// Single authoritative runtime initializer for the player car.
    /// 
    /// Startup order enforced by this bridge:
    ///   1. Load save
    ///   2. Read selected car ID from PersistentProgressManager
    ///   3. Apply appearance (via PlayerCarAppearanceController)
    ///   4. Resolve stats
    ///   5. Initialize active controller (V2 or legacy fallback)
    ///   6. Bind audio
    ///   7. Gameplay begins
    ///
    /// Key rules:
    ///   - VehicleControllerV2 does NOT self-initialize
    ///   - Legacy controller is disabled when V2 is active
    ///   - Only one audio system runs at a time
    ///   - Car identity comes from save, not from prefab defaults
    /// </summary>
    public sealed class VehicleSetupBridge : MonoBehaviour
    {
        [Header("Strategy")]
        [SerializeField] private bool useV2Controller = true;

        [Header("References")]
        [SerializeField] private VehicleControllerV2 v2Controller;
        
        [SerializeField] private PlayerCarAppearanceController appearanceController;
        [SerializeField] private Transform centerOfMassReference;

        [Header("Debug")]
        [SerializeField] private bool logStartup = true;

        public bool IsV2Active => useV2Controller && v2Controller != null && v2Controller.IsInitialized;
        public bool IsLegacyActive => false;

        private void Start()
        {
            // Resolve references
            ResolveReferences();

            // Get saved car identity
            string selectedCarId = GetSavedCarId();

            if (logStartup)
            {
                Debug.Log($"[SetupBridge] Starting vehicle initialization. Selected car: {selectedCarId}, Strategy: {(useV2Controller ? "V2" : "Legacy")}");
            }

            // Apply appearance
            if (appearanceController != null)
            {
                appearanceController.ApplyAppearance(selectedCarId);
            }

            // Resolve stats for the selected car
            VehicleStatsData stats = ResolveStats(selectedCarId);

            // Initialize the appropriate controller
            if (useV2Controller)
            {
                InitializeV2(stats);
            }
            else
            {
                InitializeLegacy(stats);
            }

            if (logStartup)
            {
                Debug.Log($"[SetupBridge] Vehicle initialization complete. Active: {(useV2Controller ? "V2" : "Legacy")}");
            }
        }

        /// <summary>
        /// Switches the active controller at runtime (for testing/migration).
        /// </summary>
        public void SwitchToV2()
        {
            if (v2Controller == null)
            {
                Debug.LogWarning("[SetupBridge] No VehicleControllerV2 found.");
                return;
            }

            useV2Controller = true;
            string carId = GetSavedCarId();
            VehicleStatsData stats = ResolveStats(carId);
            InitializeV2(stats);
        }

        public void SwitchToLegacy()
        {
            Debug.LogWarning("[SetupBridge] Legacy controller is deleted. Keeping V2 active.");
        }

        // ─────────────────────────────────────────────────────────────────────
        //  Initialization
        // ─────────────────────────────────────────────────────────────────────

        private void InitializeV2(VehicleStatsData stats)
        {
            // Disable legacy audio
            DisableLegacyAudio();

            // Enable and initialize V2
            if (v2Controller != null)
            {
                v2Controller.enabled = true;
                v2Controller.Initialize(stats);

                if (logStartup)
                {
                    Debug.Log("[SetupBridge] VehicleControllerV2 initialized.");
                }
            }
        }

        private void InitializeLegacy(VehicleStatsData stats)
        {
            Debug.LogWarning("[SetupBridge] Legacy controller is removed from the project.");
        }

        // ─────────────────────────────────────────────────────────────────────
        //  Helpers
        // ─────────────────────────────────────────────────────────────────────

        private string GetSavedCarId()
        {
            if (ServiceLocator.TryResolve<IProgressService>(out var progress))
            {
                return PlayerCarCatalog.MigrateCarId(progress.CurrentOwnedCarId);
            }

            PersistentProgressManager progressManager = FindFirstObjectByType<PersistentProgressManager>();
            if (progressManager != null)
            {
                return PlayerCarCatalog.MigrateCarId(progressManager.CurrentOwnedCarId);
            }

            Debug.LogWarning("[SetupBridge] No progress service found. Using starter car.");
            return PlayerCarCatalog.StarterCarId;
        }

        private VehicleStatsData ResolveStats(string carId)
        {
            if (PlayerCarCatalog.TryGetDefinition(carId, out PlayerCarDefinition def))
            {
                VehicleStatsData stats = def.LoadStatsAsset();
                if (stats != null)
                {
                    return stats;
                }
            }

            // Fallback: use whatever stats are already on the controller
            if (v2Controller != null)
            {
                return v2Controller.BaseStats;
            }

            Debug.LogWarning($"[SetupBridge] Could not resolve stats for car '{carId}'. Using prefab defaults.");
            return null;
        }

        private void DisableLegacyAudio()
        {
            // Legacy audio deleted.
        }

        private void ResolveReferences()
        {
            if (v2Controller == null)
            {
                v2Controller = GetComponent<VehicleControllerV2>();
            }

            if (appearanceController == null)
            {
                appearanceController = GetComponent<PlayerCarAppearanceController>();
            }
        }
    }
}
